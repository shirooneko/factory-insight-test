<div class="sidebar pinned" id="sidebar">
    <div class="sidebar-header d-flex align-items-center" >
        <img id="sidebarLogo" src="<?php echo e(asset('icons/dark/factory-insight-dark.png')); ?>" alt="Factory Insight"
            class="app-logo mx-5" style="width: 176px; height: 28.86; margin-left: 10px;" />
        <img src="<?php echo e(asset('icons/dark/pin-dark.png')); ?>" alt="Pin Sidebar" id="pinIcon" class="pin-icon"
            style="width: 24px; cursor: pointer; margin-left: 10px;">
        <img src="<?php echo e(asset('icons/dark/pin-dark.png')); ?>" alt="Unpin Sidebar" id="unpinIcon" class="unpin-icon"
            style="width: 24px; cursor: pointer; margin-left: 10px; display: none;">
    </div>
    <ul class="nav flex-column mt-4">
        <li class="nav-item">
            <a class="nav-link dropdown-toggle-custom" href="#dashboardSubmenu">
                <img src="<?php echo e(asset('icons/dark/dashboard-dark.png')); ?>" alt="Dashboard" width="18" height="18"
                    class="menu-icon">
                <span class="menu-text" style="font-size: 19px; font-weight: 500; color: white;">Dashboard</span>
                <i class="fas fa-chevron-right float-end chevron-icon"></i>
            </a>
            <ul class="collapse list-unstyled" id="dashboardSubmenu" style="padding-left: 20px;">
                <li>
                    <a class="nav-link" href="#">
                        <span class="menu-text">Overview</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <span class="menu-text">Statistics</span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link dropdown-toggle-custom" href="#masterDataSubmenu">
                <img src="<?php echo e(asset('icons/dark/master-data-dark.png')); ?>" alt="Master Data" width="18" height="18"
                    class="menu-icon">
                <span class="menu-text" style="font-size: 19px; font-weight: 500; color: white;">Master Data</span>
                <i class="fas fa-chevron-right float-end chevron-icon"></i>
            </a>
            <ul class="collapse list-unstyled" id="masterDataSubmenu" style="padding-left: 20px;">
                <li>
                    <a class="nav-link" href="#">
                        <img src="<?php echo e(asset('icons/dark/access-level-dark.png')); ?>" alt="Access Level" class="menu-icon">
                        <span class="menu-text">Access Level</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <img src="<?php echo e(asset('icons/dark/user-dark.png')); ?>" alt="Users" class="menu-icon">
                        <span class="menu-text">Users</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <img src="<?php echo e(asset('icons/dark/machine-dark.png')); ?>" alt="Machines" class="menu-icon">
                        <span class="menu-text">Machines</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="<?php echo e(route('models.index')); ?>">
                        <img src="<?php echo e(asset('icons/dark/model-dark.png')); ?>" alt="Models" class="menu-icon">
                        <span class="menu-text">Models</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="<?php echo e(route('parts.index')); ?>">
                        <img src="<?php echo e(asset('icons/dark/part-dark.png')); ?>" alt="Parts" class="menu-icon">
                        <span class="menu-text">Parts</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <img src="<?php echo e(asset('icons/dark/dies-dark.png')); ?>" alt="Dies" class="menu-icon">
                        <span class="menu-text">Dies</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <img src="<?php echo e(asset('icons/dark/cart-dark.png')); ?>" alt="Carts" class="menu-icon">
                        <span class="menu-text">Carts</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <img src="<?php echo e(asset('icons/dark/reject-reason-dark.png')); ?>" alt="Reject Reason"
                            class="menu-icon">
                        <span class="menu-text">Reject Reason</span>
                    </a>
                </li>
            </ul>
        </li>

        <!-- Menu Information -->
        <li class="nav-item">
            <a class="nav-link dropdown-toggle-custom" href="#informationSubmenu">
                <img src="<?php echo e(asset('icons/dark/information-dark.png')); ?>" alt="Information" width="18" height="18"
                    class="menu-icon">
                <span class="menu-text" style="font-size: 19px; font-weight: 500; color: white;">Information</span>
                <i class="fas fa-chevron-right float-end chevron-icon"></i>
            </a>
            <ul class="collapse list-unstyled" id="informationSubmenu" style="padding-left: 20px;">
                <li>
                    <a class="nav-link" href="#">
                        <span class="menu-text">Info 1</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <span class="menu-text">Info 2</span>
                    </a>
                </li>
            </ul>
        </li>

        <!-- Menu Transaction -->
        <li class="nav-item">
            <a class="nav-link dropdown-toggle-custom" href="#transactionSubmenu">
                <img src="<?php echo e(asset('icons/dark/transaction-dark.png')); ?>" alt="Transaction" width="18" height="18"
                    class="menu-icon">
                <span class="menu-text" style="font-size: 19px; font-weight: 500; color: white;">Transaction</span>
                <i class="fas fa-chevron-right float-end chevron-icon"></i>
            </a>
            <ul class="collapse list-unstyled" id="transactionSubmenu" style="padding-left: 20px;">
                <li>
                    <a class="nav-link" href="#">
                        <span class="menu-text">Transaction 1</span>
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#">
                        <span class="menu-text">Transaction 2</span>
                    </a>
                </li>
            </ul>
        </li>

        <!-- Menu Reports -->
        <li class="nav-item">
            <a class="nav-link" href="#">
                <img src="<?php echo e(asset('icons/dark/report-dark.png')); ?>" alt="Reports" width="18" height="18"
                    class="menu-icon">
                <span class="menu-text" style="font-size: 19px; font-weight: 500; color: white;">Reports</span>
            </a>
        </li>
    </ul>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        var sidebar = document.getElementById('sidebar');
        var pinIcon = document.getElementById('pinIcon');
        var unpinIcon = document.getElementById('unpinIcon');
        var sidebarLogo = document.getElementById('sidebarLogo');
        var currentUrl = window.location.href;

        // Dropdown Master Data
        var masterDataDropdownToggle = document.querySelector('.nav-link.dropdown-toggle-custom[href="#masterDataSubmenu"]');
        var masterDataSubmenu = document.querySelector('#masterDataSubmenu');
        var masterDataChevronIcon = masterDataDropdownToggle.querySelector('.chevron-icon');

        // Tambahkan kelas active pada submenu yang sesuai dengan URL saat ini untuk Master Data
        var masterDataLinks = masterDataSubmenu.querySelectorAll('.nav-link');
        masterDataLinks.forEach(function (link) {
            if (link.href === currentUrl) {
                link.classList.add('active');
                masterDataSubmenu.classList.add('show');
                masterDataSubmenu.style.maxHeight = masterDataSubmenu.scrollHeight + "px";
                masterDataChevronIcon.classList.remove('fa-chevron-right');
                masterDataChevronIcon.classList.add('fa-chevron-down');
            }
        });

        masterDataDropdownToggle.addEventListener('click', function (event) {
            event.preventDefault();
            if (masterDataSubmenu.classList.contains('show')) {
                masterDataSubmenu.classList.remove('show');
                masterDataSubmenu.style.maxHeight = null;
                masterDataChevronIcon.classList.remove('fa-chevron-down');
                masterDataChevronIcon.classList.add('fa-chevron-right');
            } else {
                masterDataSubmenu.classList.add('show');
                masterDataSubmenu.style.maxHeight = masterDataSubmenu.scrollHeight + "px";
                masterDataChevronIcon.classList.remove('fa-chevron-right');
                masterDataChevronIcon.classList.add('fa-chevron-down');
            }
        });

        // Dropdown Dashboard
        var dashboardDropdownToggle = document.querySelector('.nav-link.dropdown-toggle-custom[href="#dashboardSubmenu"]');
        var dashboardSubmenu = document.querySelector('#dashboardSubmenu');
        var dashboardChevronIcon = dashboardDropdownToggle.querySelector('.chevron-icon');

        dashboardDropdownToggle.addEventListener('click', function (event) {
            event.preventDefault();
            if (dashboardSubmenu.classList.contains('show')) {
                dashboardSubmenu.classList.remove('show');
                dashboardSubmenu.style.maxHeight = null;
                dashboardChevronIcon.classList.remove('fa-chevron-down');
                dashboardChevronIcon.classList.add('fa-chevron-right');
            } else {
                dashboardSubmenu.classList.add('show');
                dashboardSubmenu.style.maxHeight = dashboardSubmenu.scrollHeight + "px";
                dashboardChevronIcon.classList.remove('fa-chevron-right');
                dashboardChevronIcon.classList.add('fa-chevron-down');
            }
        });

        // Dropdown Information
        var informationDropdownToggle = document.querySelector('.nav-link.dropdown-toggle-custom[href="#informationSubmenu"]');
        var informationSubmenu = document.querySelector('#informationSubmenu');
        var informationChevronIcon = informationDropdownToggle.querySelector('.chevron-icon');

        informationDropdownToggle.addEventListener('click', function (event) {
            event.preventDefault();
            if (informationSubmenu.classList.contains('show')) {
                informationSubmenu.classList.remove('show');
                informationSubmenu.style.maxHeight = null;
                informationChevronIcon.classList.remove('fa-chevron-down');
                informationChevronIcon.classList.add('fa-chevron-right');
            } else {
                informationSubmenu.classList.add('show');
                informationSubmenu.style.maxHeight = informationSubmenu.scrollHeight + "px";
                informationChevronIcon.classList.remove('fa-chevron-right');
                informationChevronIcon.classList.add('fa-chevron-down');
            }
        });

        // Dropdown Transaction
        var transactionDropdownToggle = document.querySelector('.nav-link.dropdown-toggle-custom[href="#transactionSubmenu"]');
        var transactionSubmenu = document.querySelector('#transactionSubmenu');
        var transactionChevronIcon = transactionDropdownToggle.querySelector('.chevron-icon');

        transactionDropdownToggle.addEventListener('click', function (event) {
            event.preventDefault();
            if (transactionSubmenu.classList.contains('show')) {
                transactionSubmenu.classList.remove('show');
                transactionSubmenu.style.maxHeight = null;
                transactionChevronIcon.classList.remove('fa-chevron-down');
                transactionChevronIcon.classList.add('fa-chevron-right');
            } else {
                transactionSubmenu.classList.add('show');
                transactionSubmenu.style.maxHeight = transactionSubmenu.scrollHeight + "px";
                transactionChevronIcon.classList.remove('fa-chevron-right');
                transactionChevronIcon.classList.add('fa-chevron-down');
            }
        });

        // Menangani pin/unpin sidebar
        pinIcon.addEventListener('click', function () {
            sidebar.classList.add('pinned');
            sidebarLogo.style.display = 'block';
            pinIcon.style.display = 'none';
            unpinIcon.style.display = 'inline';
        });

        unpinIcon.addEventListener('click', function () {
            sidebar.classList.remove('pinned');
            sidebarLogo.style.display = 'none';
            pinIcon.style.display = 'inline';
            unpinIcon.style.display = 'none';
        });

        // Fungsi untuk memeriksa ukuran layar dan mengatur sidebar
        function checkScreenSize() {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('pinned');
                sidebarLogo.style.display = 'none';
                pinIcon.style.display = 'inline';
                unpinIcon.style.display = 'none';
            } else {
                sidebarLogo.style.display = 'block';
            }
        }

        checkScreenSize();
        window.addEventListener('resize', checkScreenSize);
    });
</script><?php /**PATH E:\xixixi\projek\laravel\factory-insight-test\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>